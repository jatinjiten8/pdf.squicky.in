const express = require('express');
const fileUpload = require('express-fileupload');
const path = require('path');
const cors = require('cors');
const fs = require('fs');
const bodyParser = require('body-parser');
const convertDocsToPdf = require('./tools/docsToPdf');
const compressPdf = require('./tools/compressPdf'); // Import compression utility
const docsToPdfRouter = require('./tools/docsToPdf');

// Import additional tools
const mergePdf = require('./tools/mergePdf');
const pdfToDocs = require('./tools/pdfToDocs');
const pdfToImages = require('./tools/pdfToImages');
const protectPdf = require('./tools/protectPdf');
const splitPdf = require('./tools/splitPdf');
const webToPdf = require('./tools/webToPdf');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(fileUpload());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Ensure directories exist
const uploadDir = path.join(__dirname, 'uploads');
const convertedDir = path.join(__dirname, 'converted');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);
if (!fs.existsSync(convertedDir)) fs.mkdirSync(convertedDir);

// Routes
app.use('/api', docsToPdfRouter.router);

app.post('/convert/docs-to-pdf', async (req, res) => {
  const file = req.files.file;
  const uploadPath = path.join(__dirname, 'uploads', file.name);
  const outputPath = path.join(__dirname, 'converted', `${path.parse(file.name).name}.pdf`);

  await file.mv(uploadPath);
  await convertDocsToPdf(uploadPath, outputPath);
  res.download(outputPath);
});

app.post('/compress/pdf', async (req, res) => {
  try {
    const file = req.files.file;
    const uploadPath = path.join(uploadDir, file.name);
    const outputPath = path.join(convertedDir, `${path.parse(file.name).name}-compressed.pdf`);

    await file.mv(uploadPath); // Save uploaded file
    await compressPdf(uploadPath, outputPath); // Compress PDF

    res.download(outputPath); // Send compressed file to user
  } catch (error) {
    console.error('Error during PDF compression:', error);
    res.status(500).send('An error occurred while compressing the PDF.');
  }
});

// API route for merging PDFs
app.post('/merge/pdf', async (req, res) => {
  try {
    const files = req.files.files; // Array of files
    const outputPath = path.join(convertedDir, 'merged.pdf');

    await mergePdf(files, outputPath);
    res.download(outputPath);
  } catch (error) {
    console.error('Error during PDF merging:', error);
    res.status(500).send('An error occurred while merging PDFs.');
  }
});

// API route for converting PDF to Docs
app.post('/convert/pdf-to-docs', async (req, res) => {
  try {
    const file = req.files.file;
    const uploadPath = path.join(uploadDir, file.name);
    const outputPath = path.join(convertedDir, `${path.parse(file.name).name}.docx`);

    await file.mv(uploadPath);
    await pdfToDocs(uploadPath, outputPath);
    res.download(outputPath);
  } catch (error) {
    console.error('Error during PDF to Docs conversion:', error);
    res.status(500).send('An error occurred while converting PDF to Docs.');
  }
});

// API route for converting PDF to Images
app.post('/convert/pdf-to-images', async (req, res) => {
  try {
    const file = req.files.file;
    const uploadPath = path.join(uploadDir, file.name);
    const outputDir = path.join(convertedDir, `${path.parse(file.name).name}_images`);

    if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir);

    await file.mv(uploadPath);
    await pdfToImages(uploadPath, outputDir);
    res.zip(outputDir); // Send images as a ZIP file
  } catch (error) {
    console.error('Error during PDF to Images conversion:', error);
    res.status(500).send('An error occurred while converting PDF to Images.');
  }
});

// API route for protecting PDFs
app.post('/protect/pdf', async (req, res) => {
  try {
    const file = req.files.file;
    const uploadPath = path.join(uploadDir, file.name);
    const outputPath = path.join(convertedDir, `${path.parse(file.name).name}-protected.pdf`);

    const { userPassword, ownerPassword, permissions } = req.body;

    await file.mv(uploadPath);
    await protectPdf(uploadPath, outputPath, userPassword, ownerPassword, permissions);
    res.download(outputPath);
  } catch (error) {
    console.error('Error during PDF protection:', error);
    res.status(500).send('An error occurred while protecting the PDF.');
  }
});

// API route for splitting PDFs
app.post('/split/pdf', async (req, res) => {
  try {
    const file = req.files.file;
    const uploadPath = path.join(uploadDir, file.name);
    const outputDir = path.join(convertedDir, `${path.parse(file.name).name}_split`);

    if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir);

    const { splitMethod, pageRange, splitEvery } = req.body;

    await file.mv(uploadPath);
    await splitPdf(uploadPath, outputDir, splitMethod, pageRange, splitEvery);
    res.zip(outputDir); // Send split files as a ZIP file
  } catch (error) {
    console.error('Error during PDF splitting:', error);
    res.status(500).send('An error occurred while splitting the PDF.');
  }
});

// API route for converting Web to PDF
app.post('/convert/web-to-pdf', async (req, res) => {
  try {
    const { url, pageSize, orientation, includeBackground } = req.body;
    const outputPath = path.join(convertedDir, 'webpage.pdf');

    await webToPdf(url, outputPath, pageSize, orientation, includeBackground);
    res.download(outputPath);
  } catch (error) {
    console.error('Error during Web to PDF conversion:', error);
    res.status(500).send('An error occurred while converting Web to PDF.');
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
