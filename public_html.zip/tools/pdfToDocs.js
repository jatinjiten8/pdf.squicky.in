const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { exec } = require('child_process');

const router = express.Router();

// Configure multer for file uploads
const upload = multer({ dest: 'uploads/' });

// PDF to Docs endpoint
router.post('/pdf-to-docs', upload.single('file'), async (req, res) => {
  const file = req.file;
  const { outputFormat, preserveFormatting, extractImages } = req.body;

  if (!file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }

  const outputFilePath = path.join('converted', `${path.parse(file.originalname).name}.${outputFormat}`);

  try {
    let command = `soffice --headless --convert-to ${outputFormat} --outdir converted ${file.path}`;

    if (extractImages === 'true') {
      command += ' --extract-images';
    }

    exec(command, (error, stdout, stderr) => {
      // Clean up uploaded file
      fs.unlinkSync(file.path);

      if (error) {
        console.error('Conversion error:', error);
        return res.status(500).json({ error: 'Failed to convert PDF to the selected format' });
      }

      res.download(outputFilePath, (err) => {
        if (err) {
          console.error('Error sending converted file:', err);
        }
        // Clean up converted file after download
        fs.unlinkSync(outputFilePath);
      });
    });
  } catch (err) {
    console.error('Error during conversion:', err);
    res.status(500).json({ error: 'An unexpected error occurred' });
  }
});

module.exports = router;