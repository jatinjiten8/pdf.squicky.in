// File Upload Handling
const fileInput = document.getElementById('fileInput');
const uploadBox = document.getElementById('uploadBox');
const fileInfo = document.getElementById('fileInfo');
const compressBtn = document.getElementById('compressBtn');
const progressContainer = document.getElementById('progressContainer');
const progressBar = document.getElementById('progressBar');
const progressText = document.getElementById('progressText');
const result = document.getElementById('result');
const downloadBtn = document.getElementById('downloadBtn');
const compressionStats = document.getElementById('compressionStats');

// Size Converter Elements
const sizeValue = document.getElementById('sizeValue');
const sizeFrom = document.getElementById('sizeFrom');
const sizeTo = document.getElementById('sizeTo');
const convertBtn = document.getElementById('convertBtn');
const conversionResult = document.getElementById('conversionResult');

let currentFile = null;
let currentDownloadUrl = null;

// Handle drag and drop
uploadBox.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadBox.style.borderColor = '#4361ee';
    uploadBox.style.backgroundColor = 'rgba(67, 97, 238, 0.05)';
});

uploadBox.addEventListener('dragleave', () => {
    uploadBox.style.borderColor = '#dee2e6';
    uploadBox.style.backgroundColor = '';
});

uploadBox.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadBox.style.borderColor = '#dee2e6';
    uploadBox.style.backgroundColor = '';
    
    if (e.dataTransfer.files.length > 0) {
        handleFile(e.dataTransfer.files[0]);
    }
});

// Handle file selection
uploadBox.addEventListener('click', () => {
    fileInput.click();
});

fileInput.addEventListener('change', () => {
    if (fileInput.files.length > 0) {
        handleFile(fileInput.files[0]);
    }
});

// Process selected file
function handleFile(file) {
    // Check if file is PDF
    if (file.type === 'application/pdf' || file.name.endsWith('.pdf')) {
        currentFile = file;
        updateFileInfo(file);
        
        // Reset previous results
        result.style.display = 'none';
        progressContainer.style.display = 'none';
        compressBtn.disabled = false;
    } else {
        alert('Please upload a PDF file.');
    }
}

// Update the file info UI
function updateFileInfo(file) {
    fileInfo.innerHTML = `
        <p>File: <span class="file-size">${file.name}</span></p>
        <p>Size: <span class="file-size">${formatFileSize(file.size)}</span></p>
    `;
}

// Format file size
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Size conversion function
function convertSize(value, fromUnit, toUnit) {
    const units = {
        bytes: 1,
        kb: 1024,
        mb: 1024 * 1024
    };
    
    // Convert to bytes first
    const bytes = value * units[fromUnit];
    
    // Convert to target unit
    return bytes / units[toUnit];
}

// Convert button click handler
convertBtn.addEventListener('click', () => {
    const value = parseFloat(sizeValue.value);
    
    if (isNaN(value) {
        alert('Please enter a valid number');
        return;
    }
    
    const fromUnit = sizeFrom.value;
    const toUnit = sizeTo.value;
    
    const convertedValue = convertSize(value, fromUnit, toUnit);
    
    conversionResult.innerHTML = `
        ${value.toFixed(2)} ${fromUnit.toUpperCase()} = 
        <strong>${convertedValue.toFixed(2)} ${toUnit.toUpperCase()}</strong>
    `;
    conversionResult.style.display = 'block';
});

// Compress button click handler
compressBtn.addEventListener('click', async () => {
    if (!currentFile) return;
    
    // Show progress
    progressContainer.style.display = 'block';
    compressBtn.disabled = true;
    
    try {
        const formData = new FormData();
        formData.append('file', currentFile);
        
        // Get selected compression level
        const compressionLevel = document.querySelector('input[name="compression"]:checked').value;
        
        // Add compression level to form data if your backend supports it
        // formData.append('compressionLevel', compressionLevel);
        
        // Show upload progress
        progressText.textContent = 'Uploading file...';
        
        const response = await fetch('/compress/pdf', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error(await response.text() || 'Compression failed');
        }
        
        // Get the compressed file as a blob
        const blob = await response.blob();
        const compressedFileUrl = URL.createObjectURL(blob);
        
        // Update download button
        downloadBtn.href = compressedFileUrl;
        downloadBtn.download = currentFile.name.replace('.pdf', '-compressed.pdf');
        
        // Calculate file sizes for stats
        const originalSize = currentFile.size;
        const compressedSize = blob.size;
        const reduction = ((originalSize - compressedSize) / originalSize * 100).toFixed(0);
        
        // Show result
        progressContainer.style.display = 'none';
        result.style.display = 'block';
        
        compressionStats.innerHTML = `
            <p>Original size: <strong>${formatFileSize(originalSize)}</strong></p>
            <p>Compressed size: <strong>${formatFileSize(compressedSize)}</strong></p>
            <p>Reduction: <strong>${reduction}%</strong></p>
        `;
        
    } catch (error) {
        console.error('Error:', error);
        progressContainer.style.display = 'none';
        compressBtn.disabled = false;
        alert(error.message || 'Compression failed. Please try again.');
    }
});

// Clean up object URL when download is complete
downloadBtn.addEventListener('click', () => {
    if (currentDownloadUrl) {
        URL.revokeObjectURL(currentDownloadUrl);
    }
    currentDownloadUrl = downloadBtn.href;
    
    // Hide the result section after download
    setTimeout(() => {
        result.style.display = 'none';
    }, 3000);
});

// Clean up any object URLs when the page is unloaded
window.addEventListener('beforeunload', () => {
    if (currentDownloadUrl) {
        URL.revokeObjectURL(currentDownloadUrl);
    }
});