const express = require('express');
const puppeteer = require('puppeteer');
const path = require('path');
const fs = require('fs');

const router = express.Router();

// Web to PDF endpoint
router.post('/web-to-pdf', async (req, res) => {
  const { url, pageSize, orientation, includeBackground } = req.body;

  if (!url) {
    return res.status(400).json({ error: 'URL is required' });
  }

  try {
    const browser = await puppeteer.launch();
    const page = await browser.newPage();

    await page.goto(url, { waitUntil: 'networkidle2' });

    const pdfBuffer = await page.pdf({
      format: pageSize || 'A4',
      landscape: orientation === 'landscape',
      printBackground: includeBackground || false,
    });

    await browser.close();

    const outputFileName = `webpage_${Date.now()}.pdf`;
    const outputPath = path.join('converted', outputFileName);

    if (!fs.existsSync('converted')) {
      fs.mkdirSync('converted');
    }

    fs.writeFileSync(outputPath, pdfBuffer);

    res.download(outputPath, outputFileName, (err) => {
      if (err) {
        console.error('Error sending PDF file:', err);
      }
      // Clean up the file after download
      fs.unlinkSync(outputPath);
    });
  } catch (error) {
    console.error('Error generating PDF:', error);
    res.status(500).json({ error: 'Failed to generate PDF' });
  }
});

module.exports = router;