const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { PDFDocument } = require('pdf-lib');

const router = express.Router();

// Configure multer for file uploads
const upload = multer({ dest: 'uploads/' });

// Protect PDF endpoint
router.post('/protect-pdf', upload.single('file'), async (req, res) => {
  const file = req.file;
  const { userPassword, ownerPassword, allowPrinting, allowModification, allowCopy, allowAnnotations } = req.body;

  if (!file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }

  if (!userPassword) {
    return res.status(400).json({ error: 'User password is required' });
  }

  try {
    const pdfBytes = fs.readFileSync(file.path);
    const pdfDoc = await PDFDocument.load(pdfBytes);

    // Set permissions
    const permissions = {
      printing: allowPrinting === 'true' ? 'allow' : 'deny',
      modifying: allowModification === 'true' ? 'allow' : 'deny',
      copying: allowCopy === 'true' ? 'allow' : 'deny',
      annotating: allowAnnotations === 'true' ? 'allow' : 'deny',
    };

    // Encrypt the PDF
    await pdfDoc.encrypt({
      userPassword,
      ownerPassword: ownerPassword || userPassword,
      ...permissions,
    });

    const protectedPdfBytes = await pdfDoc.save();

    // Clean up uploaded file
    fs.unlinkSync(file.path);

    // Send the protected PDF
    res.setHeader('Content-Disposition', `attachment; filename="protected_${file.originalname}"`);
    res.setHeader('Content-Type', 'application/pdf');
    res.send(Buffer.from(protectedPdfBytes));
  } catch (error) {
    console.error('Error protecting PDF:', error);
    res.status(500).json({ error: 'Failed to protect PDF' });
  }
});

module.exports = router;