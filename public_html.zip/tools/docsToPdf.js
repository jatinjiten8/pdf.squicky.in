const fs = require('fs');
const libre = require('libreoffice-convert');
const express = require('express');
const multer = require('multer');
const path = require('path');
const { exec } = require('child_process');

const router = express.Router();

// Configure multer for file uploads
const upload = multer({ dest: 'uploads/' });

// Docs to PDF endpoint
router.post('/docs-to-pdf', upload.single('file'), async (req, res) => {
  const file = req.file;
  const quality = req.body.quality || 'medium';

  if (!file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }

  const outputFilePath = path.join('converted', `${path.parse(file.originalname).name}.pdf`);

  try {
    const libreOfficeCommand = `soffice --headless --convert-to pdf --outdir converted ${file.path}`;

    exec(libreOfficeCommand, (error, stdout, stderr) => {
      // Clean up uploaded file
      fs.unlinkSync(file.path);

      if (error) {
        console.error('LibreOffice error:', error);
        return res.status(500).json({ error: 'Failed to convert document to PDF' });
      }

      res.download(outputFilePath, (err) => {
        if (err) {
          console.error('Error sending converted file:', err);
        }
        // Clean up converted file after download
        fs.unlinkSync(outputFilePath);
      });
    });
  } catch (err) {
    console.error('Error converting document:', err);
    res.status(500).json({ error: 'An unexpected error occurred' });
  }
});

const convertDocsToPdf = (inputPath, outputPath) => {
  return new Promise((resolve, reject) => {
    const docxBuf = fs.readFileSync(inputPath);
    libre.convert(docxBuf, '.pdf', undefined, (err, done) => {
      if (err) return reject(err);
      fs.writeFileSync(outputPath, done);
      resolve();
    });
  });
};

module.exports = { convertDocsToPdf, router };
