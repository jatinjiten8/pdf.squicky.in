const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { PDFDocument } = require('pdf-lib');
const archiver = require('archiver');

const router = express.Router();

// Configure multer for file uploads
const upload = multer({ dest: 'uploads/' });

// Split PDF endpoint
router.post('/split-pdf', upload.single('file'), async (req, res) => {
  const file = req.file;
  const { splitMethod, pageRange, splitEvery, outputFormat } = req.body;

  if (!file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }

  try {
    const pdfBytes = fs.readFileSync(file.path);
    const pdfDoc = await PDFDocument.load(pdfBytes);
    const totalPages = pdfDoc.getPageCount();

    const outputDir = path.join('converted', `${path.parse(file.originalname).name}_split`);
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }

    const outputZipPath = path.join('converted', `${path.parse(file.originalname).name}_split.zip`);

    let ranges = [];

    if (splitMethod === 'range') {
      ranges = pageRange.split(',').map(range => {
        const [start, end] = range.split('-').map(Number);
        return { start: start || 1, end: end || totalPages };
      });
    } else if (splitMethod === 'every') {
      const every = parseInt(splitEvery, 10);
      for (let i = 0; i < totalPages; i += every) {
        ranges.push({ start: i + 1, end: Math.min(i + every, totalPages) });
      }
    }

    const splitFiles = [];

    for (const { start, end } of ranges) {
      const newPdfDoc = await PDFDocument.create();
      for (let i = start - 1; i < end; i++) {
        const [copiedPage] = await newPdfDoc.copyPages(pdfDoc, [i]);
        newPdfDoc.addPage(copiedPage);
      }

      const splitPdfBytes = await newPdfDoc.save();
      const splitFileName = `split_${start}-${end}.pdf`;
      const splitFilePath = path.join(outputDir, splitFileName);
      fs.writeFileSync(splitFilePath, splitPdfBytes);
      splitFiles.push(splitFilePath);
    }

    // Create a ZIP file of the split PDFs
    const output = fs.createWriteStream(outputZipPath);
    const archive = archiver('zip', { zlib: { level: 9 } });

    output.on('close', () => {
      res.download(outputZipPath, (err) => {
        if (err) {
          console.error('Error sending ZIP file:', err);
        }
        // Clean up ZIP file and split files after download
        fs.unlinkSync(outputZipPath);
        fs.rmdirSync(outputDir, { recursive: true });
        fs.unlinkSync(file.path);
      });
    });

    archive.on('error', (err) => {
      console.error('Archiving error:', err);
      res.status(500).json({ error: 'Failed to create ZIP file' });
    });

    archive.pipe(output);
    archive.directory(outputDir, false);
    archive.finalize();
  } catch (error) {
    console.error('Error splitting PDF:', error);
    res.status(500).json({ error: 'Failed to split PDF' });
  }
});

module.exports = router;