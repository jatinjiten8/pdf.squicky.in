const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { exec } = require('child_process');
const archiver = require('archiver');

const router = express.Router();

// Configure multer for file uploads
const upload = multer({ dest: 'uploads/' });

// PDF to Images endpoint
router.post('/pdf-to-images', upload.single('file'), async (req, res) => {
  const file = req.file;
  const { imageFormat, imageQuality, pagesRange } = req.body;

  if (!file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }

  const outputDir = path.join('converted', `${path.parse(file.originalname).name}_images`);
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  const outputZipPath = path.join('converted', `${path.parse(file.originalname).name}_images.zip`);

  try {
    const format = imageFormat || 'jpeg';
    const quality = imageQuality || 90;
    const range = pagesRange ? `-f ${pagesRange.split('-')[0]} -l ${pagesRange.split('-')[1]}` : '';

    const command = `pdftoppm -${format} -r ${quality} ${range} ${file.path} ${path.join(outputDir, 'page')}`;

    exec(command, (error, stdout, stderr) => {
      // Clean up uploaded file
      fs.unlinkSync(file.path);

      if (error) {
        console.error('Conversion error:', error);
        return res.status(500).json({ error: 'Failed to convert PDF to images' });
      }

      // Create a ZIP file of the images
      const output = fs.createWriteStream(outputZipPath);
      const archive = archiver('zip', { zlib: { level: 9 } });

      output.on('close', () => {
        res.download(outputZipPath, (err) => {
          if (err) {
            console.error('Error sending ZIP file:', err);
          }
          // Clean up ZIP file after download
          fs.unlinkSync(outputZipPath);
          fs.rmdirSync(outputDir, { recursive: true });
        });
      });

      archive.on('error', (err) => {
        console.error('Archiving error:', err);
        res.status(500).json({ error: 'Failed to create ZIP file' });
      });

      archive.pipe(output);
      archive.directory(outputDir, false);
      archive.finalize();
    });
  } catch (err) {
    console.error('Error during conversion:', err);
    res.status(500).json({ error: 'An unexpected error occurred' });
  }
});

module.exports = router;