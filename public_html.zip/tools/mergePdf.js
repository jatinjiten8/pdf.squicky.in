const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

const router = express.Router();

// Configure multer for file uploads
const upload = multer({ dest: 'uploads/' });

// Merge PDF endpoint
router.post('/merge-pdf', upload.array('pdfFiles', 10), async (req, res) => {
  try {
    const files = req.files;
    if (!files || files.length < 2) {
      return res.status(400).json({ error: 'At least two PDF files are required to merge.' });
    }

    const outputFilePath = path.join('merged', `merged_${Date.now()}.pdf`);
    const inputFiles = files.map(file => file.path).join(' ');

    const gsCommand = `gs -q -dNOPAUSE -dBATCH -sDEVICE=pdfwrite -sOutputFile=${outputFilePath} ${inputFiles}`;

    exec(gsCommand, (error, stdout, stderr) => {
      // Clean up uploaded files
      files.forEach(file => fs.unlinkSync(file.path));

      if (error) {
        console.error('Ghostscript error:', error);
        return res.status(500).json({ error: 'Failed to merge PDF files.' });
      }

      res.download(outputFilePath, (err) => {
        if (err) {
          console.error('Error sending merged file:', err);
        }
        // Clean up merged file after download
        fs.unlinkSync(outputFilePath);
      });
    });
  } catch (err) {
    console.error('Error merging PDFs:', err);
    res.status(500).json({ error: 'An unexpected error occurred.' });
  }
});

module.exports = router;